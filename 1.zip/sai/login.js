// JavaScript for handling button clicks
document.addEventListener('DOMContentLoaded', function() {
    // Get the buttons by their class names
    const learnmore=document.querySelector('.submit');
    

    learnmore.addEventListener('click',function(){
        window.location.href='i.html';
    });
});