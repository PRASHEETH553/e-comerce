document.addEventListener('DOMContentLoaded', () => {
    initializeFilters();
});